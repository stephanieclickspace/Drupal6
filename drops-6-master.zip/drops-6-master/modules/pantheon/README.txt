This is the codebase for http://drupal.org/project/pantheon

It's a suite of modules to provide Pantheon integration for Drupal sites:

- pantheon_migrate: get onto the platform using backup_migrate
- pantheon_login: allow automatic logins via the Pantheon control panel
- pantheon_drush: drush integration
