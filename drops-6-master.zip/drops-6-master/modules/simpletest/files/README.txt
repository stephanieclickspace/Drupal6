$Id: README.txt,v 1.1.2.3 2009/09/14 23:05:19 boombatower Exp $
Core: Id: README.txt,v 1.1 2008/04/20 18:23:30 dries Exp

These files are use in some tests that upload files or other operations were
a file is useful. These files are copied to the files directory as specified
in the site settings. Other tests files are generated in order to save space.